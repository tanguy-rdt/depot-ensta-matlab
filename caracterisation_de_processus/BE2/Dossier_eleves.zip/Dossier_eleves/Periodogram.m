function Px = Periodogram(x)
%% Estimation du p�riodogram simple
% x: le signal temporel
%% Completer le code ci-dessous :
N  = ; % Nombre d'echantillons en fr�quence (identique au Nbre de pts en temps)
Y  = ; % Spectre du signal
Px = ; % Estimation de Gamma_xx(f)
