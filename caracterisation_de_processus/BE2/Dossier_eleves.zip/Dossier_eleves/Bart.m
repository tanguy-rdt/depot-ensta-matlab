function Px = Bart(x, K)
%% Estimation spectrale par Bartlett
% x : le signal temporel
% K : Nombre de segments (bloc)
%% Completer le code ci-dessous :
N  = ;  % Nombre de pts du signal
L  = ;  % Nombre de pts par blok (c'est un entier) 

disp(['Bart - Nombre de segments : ', num2str(K)]);
disp(['Bart - Nombre de points par segment: ', num2str(L)]);
disp(['Bart - Nombre de points non trait�: ', num2str(N), '-', num2str(L*K),':', num2str(N-L*K)]);

Px = 0;           % initialisation de Gamma_xx(f)
indice_debut = ; % initialisation de l'indice de debut du premier bloc
indice_fin   = ; % initialisation de l'indice de fin du premier bloc
for i=1:K; % Pour les K blocs :
    
    bloc_signal = ; % Extraction du signal associ� au bloc 
	
    Px = ; % Estimation de Gamma_xx(f)
    
	indice_debut = ; % nouveau indice de debut pour le bloc suivant
    indice_fin   = ; % nouveau indice de fin   pour le bloc suivant
    
end;