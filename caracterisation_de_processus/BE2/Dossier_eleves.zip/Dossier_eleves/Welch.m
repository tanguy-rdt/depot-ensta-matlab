function Px = Welch(x, L, overlap, win)
%% Estimation spectrale par Welch
% x : le signal temporel
% L : nombre de points par bloc (c'est un entier)
% overlap : Taux (entre [0 1[) de recouvement entre deux blocs cons�cutifs 
%           si 0 pas de recouvrement dans ce cas D=L
% win : entier entre [1 et 5] permettant de choisir la fenetre d'analyse 
%
% Autres grandeurs importantes :
% D : Nombre de pts permettant le d�calage entre deux s�quences cons�cutives lors du recouvrement
%     (c'est un entier)
% K : Nombre de segments (c'est un entier)
% utilise : Periodogramme_Modifie
%% Completer le code ci-dessous :
if (overlap>=1) || (overlap < 0);
    error (' Overlap pas bon ! [0 1[');
end;

N = ;             % Nombre de pts du signal
D = ;  % Nombre de pts pour r�aliser le D�calage
K = ;    % Nombre de segments (bloc)
disp(['Welch - Nombre de segments : ', num2str(K)]);
disp(['Welch - Nombre de point par segment : ', num2str(L)]);
disp(['Welch - Taux de recouvrement : ', num2str(overlap)]);
disp(['Welch - Nombre de point lors du recouvrement : ', num2str(L-D)]);

Px           = 0; % initialisation de Gamma_xx(f)
indice_debut = ; % initialisation de l'indice de debut du premier bloc
indice_fin   = ; % initialisation de l'indice de fin du premier bloc
for i=1:K;% Pour les K blocs :
    
    bloc_signal = ; % Extraction du signal associ� au bloc
    
    Px = ; % Estimation de Gamma_xx(f)
	
    indice_debut = ; % nouveau indice de debut du bloc suivant
    indice_fin   = ; % nouveau indice de fin du bloc suivant
end;