%% Version eleve
close all; clear all; clc;

%% GENERATION du signal
% Completer le code ci-dessous :
N  = ; 
fe = ;
f1 = ; A1 = ;
f2 = ; A2 = ;
f3 = ; A3 = ;
t  = ; % Echelle des temps
x1 = A1*cos(2*pi*f1*t);
x2 = A2*cos(2*pi*f2*t);
x3 = A3*cos(2*pi*f3*t);
var_bruit = ;                       % La variance du bruit
bruit = sqrt(var_bruit)*randn(1,N); % Le bruit
x     = ; % Le signal x

% Affichage signal temporel
figure(1);
subplot(221); hold on; grid on;
; % plot(...)
xlabel(' temps'); ylabel(' Amplitude'); 

%% SPECTRE d'amplitude
% Completer le code ci-dessous :
Nfft = N; % Nbre d'�chantillons en fr�quence
fftx = ;  % Spectre d'amplitude entre [0,fe]
freq = ;  % Echelle des fr�quences

% Affichage du spectre d'amplitude (�chelle lineaire/en dB) 
% sur l'intervalle [-fe/2, fe/2]
figure(1);
subplot(223); hold on; grid on; 
; % plot(...) en �chelle lineaire
xlabel(' Fr�quence'); ylabel(' | Spectre | lin�aire'); 

subplot(224); hold on; grid on; 
; % plot(...) en dB
xlabel(' Fr�quence'); ylabel(' | Spectre | dB'); 

% Detection des max : ici on en cherche 3
[Frequence0, Amplitude0] = AfficheMaxFreq(fftshift(fftx), freq, 3);

%% Periodogramme simple
% Completer le code ci-dessous :
Px0 = Periodogram(x);

% Affichage
figure(2);
subplot(221); hold on; grid; 
; % plot(...) en dB
xlabel(' Fr�quence'); ylabel(' DSP dB'); 
title(' Periodogramme');

% Detection des max : ici on en cherche 3
; % AfficheMaxFreq(...)

%% PERIODOGRAMME modifi�
% Completer le code ci-dessous :
% Fenetrage sur tout le signal, pas de recouvrement
typefen = 2; % numero de la fenetre [0 5]
Px1     = Periodogram_Modifie(x, typefen); 

% Affichage
figure(2);
subplot(222); hold on; grid; 
; % plot(...) en dB
xlabel(' Fr�quence'); ylabel(' DSP dB'); 
title(' Periodogramme modifi�');

% Detection des max : ici on en cherche 3
; % AfficheMaxFreq(...)

%% EFFET FENETRAGE pour le Periodogramme modifi�
% Completer le code ci-dessous :
%ps : aucun interet de prendre typefen=0 car cela revient � r�aliser du
% periodogramme simple !
Px_1 = ; % Periodogramme modifi� typefen= 1
Px_2 = ; % Periodogramme modifi� typefen= 2
Px_3 = ; % Periodogramme modifi� typefen= 3
Px_4 = ; % Periodogramme modifi� typefen= 4
Px_5 = ; % Periodogramme modifi� typefen= 5

% Affichage echelle en dB
figure(3);
subplot(231); hold on; grid;
plot(freq, 20*log(fftshift(Px_1)), 'b'); title(' DSP triangle ');
subplot(232); hold on; grid;
plot(freq, 20*log(fftshift(Px_2)), 'b'); title(' DSP Hamming ');
subplot(233); hold on; grid;
plot(freq, 20*log(fftshift(Px_3)), 'b'); title(' DSP Hanning ');
subplot(234); hold on; grid;
plot(freq, 20*log(fftshift(Px_4)), 'b'); title(' DSP Bartlett');
subplot(235); hold on; grid;
plot(freq, 20*log(fftshift(Px_5)), 'b'); title(' DSP Blackman');
subplot(236); hold on; grid;
plot(freq, 20*log(fftshift(Px0)), 'b'); title(' DSP periodogramme simple');

%% ETUDE BARTLETT 
% Completer le code ci-dessous :
% Division du signal en K blocs, pas de recouvrement entre les blocs, 
% DSP du signal estim�e par moyennage des differentes DSP des blocs 
K      = ;            % Nombre de blocs 
Px2    = Bart(x, K); 
freqBa = ; % Echelle des frequences associ�e � Px2

% Affichage
figure(2);
subplot(223); hold on; grid; 
; % plot(...) en dB
xlabel(' Fr�quence'); ylabel(' DSP dB'); 
title(' Periodogramme de Bartlett');

% Detection des max : ici on en cherche 3
; % AfficheMaxFreq(...)


%% ETUDE WELCH 
% Completer le code ci-dessous :
% Division du signal en K blocs, avec un recouvrement entre les blocs, 
% Fenetrage du chaque blocs
% DSP du signal estim�e par moyennage des differentes DSP des blocs 
% En fait, on se retrouve � faire la moyenne de plusieurs p�riodogramme
% modifi�
typefen = ;   % numero de la fenetre [0 5]
L       = ; % Nombre de points pas blocs 150
overlap = ; % Taux de recouvrement entre les blocs: ]0 1[  
Px3     = Welch(x, L, overlap, typefen); 
freqWe  = ; % Echelle des frequences % freqWe  = linspace(-fe./2,fe./2,length(Px3)); 

% Affichage
figure(2);
subplot(223); hold on; grid; 
; % plot(...) en dB
xlabel(' Fr�quence'); ylabel(' DSP dB'); 
title(' Periodogramme de Welch');

% Detection des max : ici on en cherche 3
; % AfficheMaxFreq(...)
