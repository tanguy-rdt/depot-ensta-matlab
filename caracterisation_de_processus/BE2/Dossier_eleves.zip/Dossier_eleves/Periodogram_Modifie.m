function Px = Periodogram_Modifie(x, win)
%% Estimation du p�riodogram Modofi�
% x   : le signal temporel
% win : entier entre [1 et 5] permettant de choisir la fenetre d'analyse
%% Completer le code ci-dessous :
N = ; % Nombre d'echantillons en fr�quence (identique au Nbre de pts en temps)

% Parametre de la fenetre de longueur N
W = ones(N,1); % Initialisation de la fenetre d'analyse
if         (win == 0); W = ;  % Fenetre Rectangulaire (pas de fenetre)
    elseif (win == 1); W = triang(N);  % Fenetre triangle 
    elseif (win == 2); W = ; % Fenetre de hamming
	elseif (win == 3); W = ; % Fenetre de hanning
	elseif (win == 4); W = ; % Fenetre de bartlett
	elseif (win == 5); W = blackman(N);% Fenetre de blackman
end;

% Estimation de la DSP
U   = ; % Coefficiant de normalisation associ� � la fenetre
xw  = ; % Application de la fenetre W sur le signal x
Y   = ; % Spectre du signal xw
Px  = ; % Estimation de Gamma_xx(f)
