%% On veut construire un signal tel que x(t)=Acos(theta(t)) 
% avec theta(t)=2piFot+pi*lambda*t^2
close all; clear all; clc;

%% Cr�ation du signal
A      = ;     % amplitude signal
duree  = ;     % dur�e du signal 2s
Fo     = ;  % fr�quence initiale de la sinuso�de
Fe     = ;  % fr�quence d'�chantillonnage
lambda = 1000;  % param�tre de modulation

n = round(Fe*duree); % nombre de points du signal
t = [0:n-1]/Fe;      % vecteur temps

theta = ; 
x = cos(theta); % le signal en fonction theta

% Ecoute du signal
%sound(x,Fe)

%% FFT
fftx = ;
freq = ;

figure; 
subplot(211); hold on; grid; 
plot(t, x, '-r.');
xlabel(' Temps'); ylabel(' Amplitude');
subplot(212); hold on; grid;
plot(freq, abs(fftshift(fftx)), '.b-');
xlabel(' Frequence'); ylabel(' Spectre');

%% TFCT
[A, F, T] = ; % TFCT (utilisation de votre fonction ecrite precedemment)
figure;
mesh(T, F, A); 
xlabel('Temps'); ylabel('Frequence');zlabel('Amplitude');
shading interp
colorbar;

%% spectrogramme
nfft = 128;
[B,F,T] = ; % specgram(); ou autres m�thodes
figure
pcolor(T,F,20*log10(abs(B)))
shading interp
colorbar